from django.contrib import admin
from .models import Classifier

admin.site.register(Classifier)
