const replaceUnderscore = (string) => {
  return string.replace(/_/g, ' ');
};

export default replaceUnderscore;